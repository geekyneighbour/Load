Action()
{	
	int x;
	int time;
	
	x = atoi(lr_eval_string("{rndNum}"));
	time = get_sec(x);
	lr_save_int(time, "time");
	
	web_set_sockets_option("SSL_VERSION", "AUTO");
	
	lr_start_transaction("01_MainPage");
/*Correlation comment: Automatic rules - Do not change!  
Original value='a4f617d0d49a441e91aa4eb93574f5b2' 
Name ='act_token' 
Type ='Rule' 
AppName ='Mail' 
RuleName ='act_token'*/
	web_reg_save_param_regexp(
		"ParamName=act_token",
		"RegExp=act=(.*?);",
		LAST);

/*Correlation comment: Automatic rules - Do not change!  
Original value='58519' 
Name ='app_id_mytracker' 
Type ='Rule' 
AppName ='Mail' 
RuleName ='mytracker'*/
	web_reg_save_param_regexp(
		"ParamName=app_id_mytracker",
		"RegExp=\"appIdMytracker\":\\ \"(.*?)\"",
		LAST);

	web_reg_save_param_regexp(
		"ParamName=client_id",
		"RegExp=clientId:\"(.*?)\"",
		LAST);

	web_reg_find("Search=All",
		"Text=<title>Mail.ru",
		LAST);

	web_url("mail.ru", 
		"URL=https://mail.ru/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t100.inf", 
		"Mode=HTML", 
		LAST);
		
	lr_end_transaction("01_MainPage",LR_AUTO);
	
	lr_start_transaction("02_Login");

/*Correlation comment: Automatic rules - Do not change!  
Original value='s10273.b1ss12743s' 
Name ='dwhsplit' 
Type ='Rule' 
AppName ='Mail' 
RuleName ='dshsplit'*/
	web_reg_save_param_regexp(
		"ParamName=dwhsplit",
		"RegExp=radarSplit\":\"(.*?)\"",
		LAST);

	web_url("login_2",
		"URL=https://account.mail.ru/login/?mode=simple&v=2.10.0&account_host=account.mail.ru&type=login&allow_external=1&app_id_mytracker={app_id_mytracker}&success_redirect=https%3A%2F%2Fe.mail.ru%2Fmessages%2Finbox%3Fback%3D1&project=home&source=mailbox&from=navi&parent_url=https%3A%2F%2Fmail.ru%2F&responsive=compact",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://mail.ru/",
		"Snapshot=t135.inf",
		"Mode=HTML",
		LAST);
		

	web_reg_find("Search=All",
		"Text=Location: https://e.mail.ru/messages/inbox",
		LAST);


	web_submit_data("auth",
		"Action=https://auth.mail.ru/cgi-bin/auth?from=navi",
		"Method=POST",
		"EncodeAtSign=YES",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://account.mail.ru/",
		"Snapshot=t143.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=username", "Value={login}", ENDITEM,
		"Name=Login", "Value={login}", ENDITEM,
		"Name=password", "Value={pass}", ENDITEM,
		"Name=Password", "Value={pass}", ENDITEM,
		"Name=saveauth", "Value=1", ENDITEM,
		"Name=new_auth_form", "Value=1", ENDITEM,
		"Name=FromAccount", "Value=opener=account&allow_external=1&twoSteps=1", ENDITEM,
		"Name=act_token", "Value={act_token}", ENDITEM,
		"Name=page", "Value=https://e.mail.ru/messages/inbox?app_id_mytracker={app_id_mytracker}&dwhsplit={dwhsplit}&from=login&x-login-auth=1", ENDITEM,
		"Name=back", "Value=1", ENDITEM,
		"Name=lang", "Value=ru_RU", ENDITEM,
		LAST);
		

	lr_end_transaction("02_Login",LR_AUTO);


	lr_start_transaction("03_LetterToSelf");

/*Correlation comment - Do not change!  Original value='d6839c0c3a8cd1f7947bdf166f2bfbc4:giDC_-cYSFAtheXX5uIAk4L8LkP_widPJqCCmJS7WPV7InRpbWUiOjE3MDEzNzAwOTUsInR5cGUiOiJjc3JmIiwibm9uY2UiOiJlZTgwNDAwMjgxZDc1MGQ4In0' Name ='token_1' Type ='Manual'*/
	web_reg_save_param_json(
		"ParamName=token_1",
		"QueryString=$.body.token",
		LAST);

	web_submit_data("short",
		"Action=https://e.mail.ru/api/v1/user/short",
		"Method=POST",
		"EncodeAtSign=YES",
		"TargetFrame=",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/tomyself/",
		"Snapshot=t159.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=email", "Value={login}", ENDITEM,
		"Name=htmlencoded", "Value=false", ENDITEM,
		LAST);

	web_reg_find("Search=All",
		"Text=\"status\":200",
		LAST);

	web_submit_data("send",
		"Action=https://e.mail.ru/api/v1/messages/send",
		"Method=POST",
		"EncodeAtSign=YES",
		"TargetFrame=",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/tomyself/",
		"Snapshot=t160.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=ATTACHMENTS_RESTORE", "Value=true", ENDITEM,
		"Name=id", "Value={id}", ENDITEM,
		"Name=id", "Value=2", ENDITEM,
		"Name=source", "Value={\"draft\":\"\",\"reply\":\"\",\"forward\":\"\",\"schedule\":\"\"}", ENDITEM,
		"Name=headers", "Value={}", ENDITEM,
		"Name=template", "Value=0", ENDITEM,
		"Name=sign", "Value=0", ENDITEM,
		"Name=remind", "Value=0", ENDITEM,
		"Name=receipt", "Value=false", ENDITEM,
		"Name=subject", "Value={letter_topic}", ENDITEM,
		"Name=priority", "Value=3", ENDITEM,
		"Name=send_date", "Value=", ENDITEM,
		"Name=body", "Value={\"html\":\"<div>{message}<br>Ну а результат работы функции у нас такой: {time}</div>\"}", ENDITEM,
		"Name=from", "Value={login}", ENDITEM,
		"Name=correspondents", "Value={\"to\":\"{login}\",\"cc\":\"\",\"bcc\":\"\"}", ENDITEM,
		"Name=folder_id", "Value=", ENDITEM,
		"Name=triggerModelChangePlease", "Value=true", ENDITEM,
		"Name=delay_for_cancellation", "Value=true", ENDITEM,
		"Name=attaches", "Value={\"list\":[]}", ENDITEM,
		"Name=email", "Value={login}", ENDITEM,
		"Name=htmlencoded", "Value=false", ENDITEM,
		"Name=token", "Value={token_1}", ENDITEM,
		LAST);


	lr_end_transaction("03_LetterToSelf",LR_AUTO);

	lr_start_transaction("04_DeleteAllFromSelf");


	web_reg_find("Search=All",
		"Text=\"status\":200",
		LAST);

	web_submit_data("all",
		"Action=https://e.mail.ru/api/v1/messages/move/all",
		"Method=POST",
		"EncodeAtSign=YES",
		"TargetFrame=",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/tomyself/",
		"Snapshot=t170.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=folder", "Value=500002", ENDITEM, //Номер папки один для всех пользователь. Проверено из ответа в функции и с помощью разных пар логин/пароль.
		"Name=folder_from", "Value=500015", ENDITEM, //Номер папки один для всех пользователь. Проверено из ответа в функции и с помощью разных пар логин/пароль.
		"Name=email", "Value={login}", ENDITEM,
		"Name=htmlencoded", "Value=false", ENDITEM,
		"Name=token", "Value={token_1}", ENDITEM,
		LAST);

	lr_end_transaction("04_DeleteAllFromSelf",LR_AUTO);


	lr_start_transaction("05_Logout");


	web_reg_find("Search=All",
		"Text=<title>Mail.ru",
		LAST);

	web_url("logout", 
		"URL=https://auth.mail.ru/cgi-bin/logout?next=1&lang=ru_RU&page=https%3A%2F%2Fmail.ru%2F%3Ffrom%3Dlogout", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://e.mail.ru/", 
		"Snapshot=t182.inf", 
		"Mode=HTML", 
		LAST);

	
	lr_end_transaction("05_Logout",LR_AUTO);

	return 0;
}