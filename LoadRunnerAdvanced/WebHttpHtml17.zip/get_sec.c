int get_sec(int x) {
int time;
lr_save_datetime("%H", DATE_NOW, "h");
lr_save_datetime("%M", DATE_NOW, "min");
lr_save_datetime("%S", DATE_NOW, "sec");

time = 	atoi(lr_eval_string("{h}")) * 3600 + atoi(lr_eval_string("{min}")) * 60 + atoi(lr_eval_string("{sec}"));

return time + x;
}