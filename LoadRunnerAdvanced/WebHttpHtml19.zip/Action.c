Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");
	

	lr_start_transaction("01_MainPage");

/*Correlation comment: Automatic rules - Do not change!  
Original value='8d9f64a119fd4194a3a8259c7c2c809c' 
Name ='act_token' 
Type ='Rule' 
AppName ='Mail' 
RuleName ='act_token'*/
	web_reg_save_param_regexp(
		"ParamName=act_token",
		"RegExp=act=(.*?);",
		LAST);

/*Correlation comment: Automatic rules - Do not change!  
Original value='58519' 
Name ='app_id_mytracker' 
Type ='Rule' 
AppName ='Mail' 
RuleName ='mytracker'*/
	web_reg_save_param_regexp(
		"ParamName=app_id_mytracker",
		"RegExp=\"appIdMytracker\":\\ \"(.*?)\"",
		LAST);

	web_reg_find("Search=All",
		"Text=<title>Mail.ru",
		LAST);

	web_url("mail.ru", 
		"URL=https://mail.ru/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);


	lr_end_transaction("01_MainPage",LR_AUTO);


	lr_start_transaction("02_Login");


/*Correlation comment: Automatic rules - Do not change!  
Original value='s10273.b1ss12743s' 
Name ='dwhsplit' 
Type ='Rule' 
AppName ='Mail' 
RuleName ='dshsplit'*/
	web_reg_save_param_regexp(
		"ParamName=dwhsplit",
		"RegExp=radarSplit\":\"(.*?)\"",
		LAST);

	web_url("login_2",
		"URL=https://account.mail.ru/login/?mode=simple&v=2.10.1&account_host=account.mail.ru&type=login&allow_external=1&app_id_mytracker={app_id_mytracker}&success_redirect=https%3A%2F%2Fe.mail.ru%2Fmessages%2Finbox%3Fback%3D1&project=home&source=mailbox&from=navi&parent_url=https%3A%2F%2Fmail.ru%2F&responsive=compact",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://mail.ru/",
		"Snapshot=t15.inf",
		"Mode=HTML",
		LAST);


	web_reg_find("Search=All",
		"Text=location: https://e.mail.ru/messages/inbox",
		LAST);

	web_submit_data("auth",
		"Action=https://auth.mail.ru/cgi-bin/auth?from=navi",
		"Method=POST",
		"EncodeAtSign=YES",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://account.mail.ru/",
		"Snapshot=t62.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=username", "Value={login}", ENDITEM,
		"Name=Login", "Value={login}", ENDITEM,
		"Name=password", "Value={pass}", ENDITEM,
		"Name=Password", "Value={pass}", ENDITEM,
		"Name=new_auth_form", "Value=1", ENDITEM,
		"Name=FromAccount", "Value=opener=account&allow_external=1&twoSteps=1", ENDITEM,
		"Name=act_token", "Value={act_token}", ENDITEM,
		"Name=page", "Value=https://e.mail.ru/messages/inbox?app_id_mytracker={app_id_mytracker}&back=1&dwhsplit={dwhsplit}&from=login&x-login-auth=1", ENDITEM,
		"Name=back", "Value=1", ENDITEM,
		"Name=lang", "Value=ru_RU", ENDITEM,
		LAST);


	lr_end_transaction("02_Login",LR_AUTO);

	lr_start_transaction("03_NewCloudFolder");
	
	/*Correlation comment: Automatic rules - Do not change!  
Original value='SV8plTMc0C' 
Name ='x-page-id' 
Type ='ResponseBased'*/
	web_reg_save_param_regexp(
		"ParamName=x-page-id",
		"RegExp=pgid\":\"(.*?)\"",
		LAST);

	web_reg_save_param_regexp(
		"ParamName=x-csrf-token",
		"RegExp=x-csrf-token:(.*)",
		LAST);
			
	web_reg_save_param_regexp(
		"ParamName=x-goog-api-key",
		"RegExp=apiKey:\"(.*?)\"",
		LAST);


	web_url("f0dxi9", 
		"URL=https://trk.mail.ru/c/f0dxi9?mt_sub1=e.mail.ru", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://e.mail.ru/", 
		"Snapshot=t91.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("X-CSRF-Token", "{x-csrf-token}");
	
	web_reg_find("Search=All",
		"Text=\"status\":200",
		LAST);

	web_submit_data("add",
		"Action=https://cloud.mail.ru/api/v2/folder/add",
		"Method=POST",
		"EncodeAtSign=YES",
		"TargetFrame=",
		"RecContentType=application/json",
		"Referer=https://cloud.mail.ru/home/",
		"Snapshot=t105.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=home", "Value=/{folder_name}", ENDITEM,
		"Name=conflict", "Value=rename", ENDITEM,
		"Name=api", "Value=2", ENDITEM,
		"Name=build", "Value=cloudweb-16022.202312051744", ENDITEM,
		"Name=x-page-id", "Value={x-page-id}", ENDITEM,
		"Name=email", "Value={login}", ENDITEM,
		"Name=x-email", "Value={login}", ENDITEM,
		LAST);


	lr_end_transaction("03_NewCloudFolder",LR_AUTO);

	lr_start_transaction("04_GetAndShareLink");
	
	web_reg_save_param_regexp(
		"ParamName=folder",
		"RegExp=body\":\"(.*?)\"",
		LAST);
	

	web_add_header("X-CSRF-Token", "{x-csrf-token}");
	
	web_custom_request("publish", 
		"URL=https://cloud.mail.ru/api/v2/file/publish", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://cloud.mail.ru/home/{folder_name}", 
		"Snapshot=t114.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"x-email\":\"{login}\",\"home\":\"/{folder_name}\"}", 
		LAST);


/*Correlation comment - Do not change!  Original value='575a71bb0631aaccd57c0519709f83e5:2feVwZ04vxLQzmeadnk4gPfJca4HNpEmmPsAKEI0LsV7InRpbWUiOjE3MDE4ODQ1MzQsInR5cGUiOiJjc3JmIiwibm9uY2UiOiJiNGU4YzdkYTE2MTRiNDZiIn0' Name ='token' Type ='Manual'*/
	web_reg_save_param_json(
		"ParamName=token",
		"QueryString=$.body.token",
		LAST);

	web_submit_data("short",
		"Action=https://e.mail.ru/api/v1/user/short",
		"Method=POST",
		"EncodeAtSign=YES",
		"TargetFrame=",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/?app_id_mytracker={app_id_mytracker}&back=1%2C1&dwhsplit={dwhsplit}&from=login%2Cnavi&x-login-auth=1&afterReload=1",
		"Snapshot=t122.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=email", "Value={login}", ENDITEM,
		"Name=htmlencoded", "Value=false", ENDITEM,
		LAST);

	web_reg_find("Search=All",
		"Text=\"status\":200",
		LAST);

	web_submit_data("send",
		"Action=https://e.mail.ru/api/v1/messages/send",
		"Method=POST",
		"EncodeAtSign=YES",
		"TargetFrame=",
		"RecContentType=application/json",
		"Referer=https://e.mail.ru/inbox/?app_id_mytracker={app_id_mytracker}&back=1%2C1&dwhsplit={dwhsplit}&from=login%2Cnavi&x-login-auth=1&afterReload=1",
		"Snapshot=t123.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=ATTACHMENTS_RESTORE", "Value=true", ENDITEM,
		"Name=id", "Value={id}", ENDITEM,
		"Name=source", "Value={\"draft\":\"\",\"reply\":\"\",\"forward\":\"\",\"schedule\":\"\"}", ENDITEM,
		"Name=headers", "Value={}", ENDITEM,
		"Name=template", "Value=0", ENDITEM,
		"Name=sign", "Value=0", ENDITEM,
		"Name=remind", "Value=0", ENDITEM,
		"Name=receipt", "Value=false", ENDITEM,
		"Name=subject", "Value={letter_topic}", ENDITEM,
		"Name=priority", "Value=3", ENDITEM,
		"Name=send_date", "Value=", ENDITEM,
		"Name=body", "Value={\"html\":\"<div><a href=\\\"https://cloud.mail.ru/public/{folder}\\\">{message}</a></div>\"}", ENDITEM,
		"Name=from", "Value=<{login}>", ENDITEM,
		"Name=correspondents", "Value={\"to\":\"<{receiver}>\",\"cc\":\"\",\"bcc\":\"\"}", ENDITEM,
		"Name=folder_id", "Value=", ENDITEM,
		"Name=triggerModelChangePlease", "Value=true", ENDITEM,
		"Name=delay_for_cancellation", "Value=true", ENDITEM,
		"Name=attaches", "Value={\"list\":[]}", ENDITEM,
		"Name=email", "Value={login}", ENDITEM,
		"Name=htmlencoded", "Value=false", ENDITEM,
		"Name=token", "Value={token}", ENDITEM,
		LAST);



	lr_end_transaction("04_GetAndShareLink",LR_AUTO);

	lr_start_transaction("05_Logout");


	web_reg_find("Search=All",
		"Text=HTTP/2.0 200",
		LAST);

	web_url("logout", 
		"URL=https://auth.mail.ru/cgi-bin/logout?next=1&lang=ru_RU&page=https%3A%2F%2Fmail.ru%2F%3Ffrom%3Dlogout", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://e.mail.ru/", 
		"Snapshot=t138.inf", 
		"Mode=HTML", 
		LAST);


	lr_end_transaction("05_Logout",LR_AUTO);

	return 0;
}