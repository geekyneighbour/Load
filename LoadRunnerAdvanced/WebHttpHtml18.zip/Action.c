Action()
{

	long currentTimestamp = time(NULL);
	char timestampString[20];

    sprintf(timestampString, "%ld", currentTimestamp);
    
    lr_save_string(timestampString, "currentTimestamp");
    
    web_set_sockets_option("SSL_VERSION", "AUTO");

	lr_start_transaction("01_MainPage");

	web_reg_save_param_regexp(
    "ParamName=clientId",
    "RegExp=CLIENT_ID\\|\\|\"(.*?)\"",
    LAST);
	
/*Correlation comment: Automatic rules - Do not change!  
Original value='fb254116f8954d61879c0751857bb3ea' 
Name ='act_token' 
Type ='Rule' 
AppName ='Mail' 
RuleName ='act_token'*/
	web_reg_save_param_regexp(
		"ParamName=act_token",
		"RegExp=act=(.*?);",
		LAST);


	web_reg_find("Search=All",
		"Text=calendar",
		LAST);

	web_url("x.calendar.mail.ru", 
		"URL=https://x.calendar.mail.ru/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t244.inf", 
		"Mode=HTML", 
		LAST);


	lr_end_transaction("01_MainPage",LR_AUTO);

	
	lr_start_transaction("02_Login");

/*Correlation comment - Do not change!  Original value='mt-mv8515-1701552185-1826284643' Name ='mt_click_id' Type ='ResponseBased'*/
	web_reg_save_param_regexp(
		"ParamName=mt_click_id",
		"RegExp=mt_click_id=(.*?)&mt_campaign",
		LAST);

	web_url("mv8515", 
		"URL=https://trk.mail.ru/c/mv8515?mt_adset=calendar_lp&mt_network=blue_button_open_header&mt_campaign=calendar_lp", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://planner.mail.ru/", 
		"Snapshot=t260.inf", 
		"Mode=HTML", 
		LAST);



/*Correlation comment: Automatic rules - Do not change!  
Original value='s10273.b1ss12743s' 
Name ='dwhsplit' 
Type ='Rule' 
AppName ='Mail' 
RuleName ='dshsplit'*/
	web_reg_save_param_regexp(
		"ParamName=dwhsplit",
		"RegExp=radarSplit\":\"(.*?)\"",
		LAST);

	web_url("login_3",
		"URL=https://account.mail.ru/login?page=https%3A%2F%2Fx.calendar.mail.ru%2F%3Fnolanding%3D1%26utm_source%3Dcalendar_lp%26utm_medium%3Dblue_button_open_header%26utm_campaign%3Dcalendar_lp%26mt_network%3Dblue_button_open_header%26mt_adset%3Dcalendar_lp%26mt_click_id%3D{mt_click_id}%26mt_campaign%3Dcalendar_lp",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://x.calendar.mail.ru/",
		"Snapshot=t265.inf",
		"Mode=HTML",
		LAST);


	web_reg_find("Search=All",
		"Text=domain=.auth.mail.ru",
		LAST);

	web_submit_data("auth",
		"Action=https://auth.mail.ru/cgi-bin/auth",
		"Method=POST",
		"EncodeAtSign=YES",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://account.mail.ru/",
		"Snapshot=t278.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=username", "Value={login}", ENDITEM,
		"Name=Login", "Value={login}", ENDITEM,
		"Name=password", "Value={pass}", ENDITEM,
		"Name=Password", "Value={pass}", ENDITEM,
		"Name=saveauth", "Value=1", ENDITEM,
		"Name=new_auth_form", "Value=1", ENDITEM,
		"Name=FromAccount", "Value=opener=account&twoSteps=1", ENDITEM,
		"Name=act_token", "Value={act_token}", ENDITEM,
		"Name=page", "Value=https://x.calendar.mail.ru/?dwhsplit={dwhsplit}&from=login&mt_adset=calendar_lp&mt_campaign=calendar_lp&mt_click_id={mt_click_id}&mt_network=blue_button_open_header&nolanding=1&utm_campaign=calendar_lp&utm_medium=blue_button_open_header&utm_source=calendar_lp", ENDITEM,
		"Name=lang", "Value=ru_RU", ENDITEM,
		LAST);

	web_reg_save_param_regexp(
		"ParamName=calendarapi_csrf",
		"RegExp=calendarapi_csrf=(.*?);",
		LAST);

	web_reg_find("Search=All",
		"Text=\"email\":\"{login}\"",
		LAST);

	web_custom_request("graphql_6",
		"URL=https://x.calendar.mail.ru/graphql",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://x.calendar.mail.ru/?dwhsplit={dwhsplit}&from=login&mt_adset=calendar_lp&mt_campaign=calendar_lp&mt_click_id={mt_click_id}&mt_network=blue_button_open_header&nolanding=1&utm_campaign=calendar_lp&utm_medium=blue_button_open_header&utm_source=calendar_lp",
		"Snapshot=t280.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operationName\":\"UserQuery\",\"variables\":{},\"query\":\"query UserQuery {\\n"
		"  user {\\n"
		"    email\\n"
		"    name\\n"
		"    workingDays\\n"
		"    workingTime {\\n"
		"      from\\n"
		"      to\\n"
		"      __typename\\n"
		"    }\\n"
		"    timezone {\\n"
		"      name\\n"
		"      offset\\n"
		"      __typename\\n"
		"    }\\n"
		"    tutorial\\n"
		"    features\\n"
		"    __typename\\n"
		"  }\\n"
		"}\\n"
		"\"}",
		LAST);
		

/*Correlation comment - Do not change!  Original value='27c25ffd-7280-497d-8e83-9a61a9bbe6c1' Name ='uid' Type ='Manual'*/
	web_reg_save_param_json(
		"ParamName=uid",
		"QueryString=$.data.calendars[0].uid",
		LAST);
		
	web_add_header("x-csrf-token", "{calendarapi_csrf}");
	
	web_custom_request("graphql_8",
		"URL=https://x.calendar.mail.ru/graphql",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://x.calendar.mail.ru/month/today/?dwhsplit={dwhsplit}&from=login&mt_adset=calendar_lp&mt_campaign=calendar_lp&mt_click_id={mt_click_id}&mt_network=blue_button_open_header&nolanding=1&utm_campaign=calendar_lp&utm_medium=blue_button_open_header&utm_source=calendar_lp",
		"Snapshot=t284.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operationName\":\"CalendarsQuery\",\"variables\":{},\"query\":\"query CalendarsQuery {\\n"
		"  calendars(onlyAccepted: false) {\\n"
		"    uid\\n"
		"    title\\n"
		"    status\\n"
		"    type\\n"
		"    access\\n"
		"    isDefault\\n"
		"    color\\n"
		"    sortWeight\\n"
		"    shareReminders\\n"
		"    receiveSharedReminders\\n"
		"    sharingToken {\\n"
		"      token\\n"
		"      access\\n"
		"      __typename\\n"
		"    }\\n"
		"    owner {\\n"
		"      email\\n"
		"      name\\n"
		"      __typename\\n"
		"    }\\n"
		"    attendees(inviteTypes: [DIRECT]) {\\n"
		"      user {\\n"
		"        name\\n"
		"        email\\n"
		"        __typename\\n"
		"      }\\n"
		"      access\\n"
		"      status\\n"
		"      __typename\\n"
		"    }\\n"
		"    reminders {\\n"
		"      type\\n"
		"      interval\\n"
		"      __typename\\n"
		"    }\\n"
		"    __typename\\n"
		"  }\\n"
		"}\\n"
		"\"}",
		LAST);



/*Correlation comment: Automatic rules - Do not change!  
Original value='f72956f20074789197781a20e74fce675656069837363830' 
Name ='access_token' 
Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=access_token",
		"RegExp=access_token\":\"(.*?)\"",
		LAST);

	web_submit_data("login_8", 
		"Action=https://o2.mail.ru/login", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://x.calendar.mail.ru/", 
		"Snapshot=t290.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=mode", "Value=hidden", ENDITEM, 
		"Name=response_type", "Value=token", ENDITEM, 
		"Name=scope", "Value=calls.api mail.api.contacts_smart mail.api.helpers mail.api.helpers.update mail.api.helpers.remove userinfo calendar.events.create calendar.events.update calendar.events.delete pushme.api.v2.setsettings cloud.openapi.dnd", ENDITEM, 
		"Name=login", "Value={login}", ENDITEM, 
		"Name=state", "Value=cid=2&e=__mailru_oauth_{currentTimestamp}000_0.5236467006595706__", ENDITEM, //генерация в оригинале происходит в функции (при входе на главную страницу): текущий unix timestamp (милисекунды) + рандом
		"Name=lang", "Value=ru", ENDITEM, 
		"Name=client_id", "Value={clientId}", ENDITEM, 
		"Name=redirect_uri", "Value=https://x.calendar.mail.ru", ENDITEM, 
		LAST);
		
	lr_end_transaction("02_Login",LR_AUTO);


	lr_start_transaction("03_NewEvent");
	
	web_add_header("x-csrf-token", "{calendarapi_csrf}");

	web_reg_find("Search=All",
		"Text=createEvent",
		LAST);

	web_custom_request("graphql_14",
		"URL=https://x.calendar.mail.ru/graphql",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://x.calendar.mail.ru/month/2024/{randomMonth}/{randomDay}/?dwhsplit={dwhsplit}&from=login&mt_adset=calendar_lp&mt_campaign=calendar_lp&mt_click_id={mt_click_id}&mt_network=blue_button_open_header&nolanding=1&utm_campaign=calendar_lp&utm_medium=blue_button_open_header&utm_source=calendar_lp&selectedDate=2024-{randomMonth}-{randomDay}",
		"Snapshot=t301.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operationName\":\"CreateEvent\",\"variables\":{\"input\":{\"uid\":\"{uid1}-{uid2}-{uid3}-{uid4}-{uid5}\",\"title\":\"{title}\",\"description\":\"\",\"calendar\":\"{uid}\",\"location\":{\"description\":\"\",\"geo\":null},\"from\":\"2024-{randomMonth}-{randomDay}T11:00:00.000Z\",\"to\":\"2024-{randomMonth}-{randomDay}T11:30:00.000Z\",\"fullDay\":false,\"attendees\":[{\"email\":\"{participant}\",\"role\":\"REQUIRED\"}],\"attaches\":[],\"reminders\":[{\"type\":\"email\",\"interval\":900},{\"type\":\"push\",\"interval\":300}],\"color\":\"\"}},\"query\":\"mutation CreateEvent($input: EventInput!) {\\n"
		"  createEvent(event: $input) {\\n"
		"    uid\\n"
		"    title\\n"
		"    from\\n"
		"    to\\n"
		"    fullDay\\n"
		"    description\\n"
		"    recurrenceID\\n"
		"    calendar {\\n"
		"      uid\\n"
		"      __typename\\n"
		"    }\\n"
		"    reminders {\\n"
		"      interval\\n"
		"      type\\n"
		"      __typename\\n"
		"    }\\n"
		"    attaches {\\n"
		"      url\\n"
		"      shareID\\n"
		"      filename\\n"
		"      size\\n"
		"      __typename\\n"
		"    }\\n"
		"    call\\n"
		"    location {\\n"
		"      description\\n"
		"      __typename\\n"
		"    }\\n"
		"    recurrence {\\n"
		"      freq\\n"
		"      weekdays {\\n"
		"        day\\n"
		"        __typename\\n"
		"      }\\n"
		"      monthdays\\n"
		"      interval\\n"
		"      __typename\\n"
		"    }\\n"
		"    __typename\\n"
		"  }\\n"
		"}\\n"
		"\"}",
		LAST);


	lr_end_transaction("03_NewEvent",LR_AUTO);

	lr_start_transaction("04_Logout");


	web_reg_find("Search=All",
		"Text=HTTP/2.0 200",
		LAST);

	web_url("logout", 
		"URL=https://auth.mail.ru/cgi-bin/logout?next=1&lang=ru_RU&page=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://x.calendar.mail.ru/", 
		"Snapshot=t305.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("04_Logout",LR_AUTO);

	return 0;
}